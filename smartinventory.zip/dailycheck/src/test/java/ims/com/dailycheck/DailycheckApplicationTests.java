package ims.com.dailycheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DailycheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
