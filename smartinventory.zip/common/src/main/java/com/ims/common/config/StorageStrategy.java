package com.ims.common.config;

public enum StorageStrategy {
    FIFO,
    LIFO,
    FEFO,
    RANDOM
}
