package com.ims.common.config;

public enum ProductType {
    FOOD,
    ELECTRONICS,
    CLOTHING,
    RAW_MATERIAL,
    PHARMACEUTICALS,
    COSMETICS,
    BOOKS;
}