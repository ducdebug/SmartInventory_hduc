package com.ims.common.config;

public enum TransactionType {
    IMPORT,
    EXPORT,
    MAINTENANCE
}
