package com.ims.common.config;

public enum SectionStatus {
    TERMINATED,
    ACTIVE
}
