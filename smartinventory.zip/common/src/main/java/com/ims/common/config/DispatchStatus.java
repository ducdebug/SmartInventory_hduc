package com.ims.common.config;

public enum DispatchStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
}