package com.ims.common.config;

public enum UserRole {
    ADMIN,
    SUPPLIER,
    BUYER
}