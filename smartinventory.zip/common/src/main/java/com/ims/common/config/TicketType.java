package com.ims.common.config;

public enum TicketType {
    REQUEST_PRODUCT,
    
}
