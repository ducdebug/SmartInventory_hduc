package com.ims.common.config;

public enum ClothingSize {
    XS,
    S,
    M,
    L,
    XL
}
