package com.ims.common.config;

public enum StorageConditions {
    TEMPERATURE_CONTROLLED,
    HUMIDITY_CONTROLLED,
    HAZARDOUS_MATERIALS
}