package com.ims.common.config;

public enum LotStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    PEND_WITHDRAW,
    WITHDRAWN
}
