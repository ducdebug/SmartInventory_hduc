package com.ims.smartinventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartInventoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
