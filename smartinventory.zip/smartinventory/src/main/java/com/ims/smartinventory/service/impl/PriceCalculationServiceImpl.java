package com.ims.smartinventory.service.impl;

import com.ims.common.config.StorageConditions;
import com.ims.smartinventory.dto.Request.PriceCalculationRequestDto;
import com.ims.smartinventory.dto.Response.PriceCalculationResponseDto;
import com.ims.smartinventory.service.PriceCalculationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class PriceCalculationServiceImpl implements PriceCalculationService {
    
    // Base price per slot per month (in USD)
    private static final double BASE_PRICE_PER_SLOT = 10.0;
    private static final String CURRENCY = "USD";
    
    @Override
    public PriceCalculationResponseDto calculatePrice(PriceCalculationRequestDto request) {
        return calculatePrice(request.getStorageConditions(), request.getSlotCount());
    }
    
    @Override
    public PriceCalculationResponseDto calculatePrice(List<StorageConditions> storageConditions, int slotCount) {
        log.debug("Calculating price for {} slots with {} storage conditions", 
                 slotCount, storageConditions.size());
        
        if (slotCount <= 0) {
            throw new IllegalArgumentException("Slot count must be greater than 0");
        }
        
        double basePrice = BASE_PRICE_PER_SLOT * slotCount;
        double multiplier = 1.0;
        List<String> appliedConditions = new ArrayList<>();
        
        // Apply multipliers based on storage conditions
        for (StorageConditions condition : storageConditions) {
            switch (condition) {
                case TEMPERATURE_CONTROLLED:
                    multiplier += 0.5; // +50% for temperature control
                    appliedConditions.add("Temperature Control (+50%)");
                    log.debug("Applied temperature control multiplier: +50%");
                    break;
                case HUMIDITY_CONTROLLED:
                    multiplier += 0.3; // +30% for humidity control
                    appliedConditions.add("Humidity Control (+30%)");
                    log.debug("Applied humidity control multiplier: +30%");
                    break;
                case HAZARDOUS_MATERIALS:
                    multiplier += 1.0; // +100% for hazardous materials
                    appliedConditions.add("Hazardous Materials (+100%)");
                    log.debug("Applied hazardous materials multiplier: +100%");
                    break;
                default:
                    log.debug("No price multiplier for condition type: {}", condition);
                    break;
            }
        }
        
        double finalPrice = basePrice * multiplier;
        
        // Create breakdown text
        StringBuilder breakdown = new StringBuilder();
        breakdown.append(String.format("Base price: $%.2f/slot × %d slots = $%.2f%n", 
                        BASE_PRICE_PER_SLOT, slotCount, basePrice));
        
        if (!appliedConditions.isEmpty()) {
            breakdown.append("Applied conditions:%n");
            for (String condition : appliedConditions) {
                breakdown.append("  - ").append(condition).append("%n");
            }
            breakdown.append(String.format("Total multiplier: %.1fx%n", multiplier));
        }
        
        breakdown.append(String.format("Final price: $%.2f × %.1f = $%.2f per month", 
                        basePrice, multiplier, finalPrice));
        
        log.info("Calculated price: ${} {} for {} slots with {}% condition markup", 
                finalPrice, CURRENCY, slotCount, (multiplier - 1.0) * 100);
        
        return new PriceCalculationResponseDto(
            basePrice,
            finalPrice,
            multiplier,
            CURRENCY,
            slotCount,
            breakdown.toString()
        );
    }
}
