package com.ims.smartinventory.exception;

public class NoSuitableSectionException extends StorageException {
    public NoSuitableSectionException(String message) {
        super(message);
    }
}
