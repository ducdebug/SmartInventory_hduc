package com.ims.smartinventory.service;

public interface PriceUpdateService {
    /**
     * Updates prices for all active sections based on monthly increment
     */
    void updateMonthlyPrices();
    
    /**
     * Updates price for a specific section
     */
    void updateSectionPrice(String sectionId);
}
