package com.ims.smartinventory.controller;

import com.ims.smartinventory.dto.Request.PriceCalculationRequestDto;
import com.ims.smartinventory.dto.Response.PriceCalculationResponseDto;
import com.ims.smartinventory.service.PriceCalculationService;
import com.ims.smartinventory.service.PriceUpdateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/price")
@CrossOrigin(origins = "*", maxAge = 3600)
public class PriceController {
    
    private final PriceUpdateService priceUpdateService;
    private final PriceCalculationService priceCalculationService;
    
    public PriceController(PriceUpdateService priceUpdateService, 
                          PriceCalculationService priceCalculationService) {
        this.priceUpdateService = priceUpdateService;
        this.priceCalculationService = priceCalculationService;
    }
    
    /**
     * Calculate price for given storage conditions and slot count
     * This is used by frontend to show price before section creation
     */
    @PostMapping("/calculate")
    public ResponseEntity<PriceCalculationResponseDto> calculatePrice(@RequestBody PriceCalculationRequestDto request) {
        try {
            log.info("Price calculation requested for {} slots with {} storage conditions", 
                    request.getSlotCount(), request.getStorageConditions().size());
            
            PriceCalculationResponseDto response = priceCalculationService.calculatePrice(request);
            
            log.info("Price calculation completed: ${} USD", response.getFinalPrice());
            return ResponseEntity.ok(response);
            
        } catch (IllegalArgumentException e) {
            log.warn("Invalid price calculation request: {}", e.getMessage());
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            log.error("Failed to calculate price", e);
            return ResponseEntity.internalServerError().build();
        }
    }
    
    /**
     * Manually trigger monthly price update for all active sections
     */
    @PostMapping("/update-all")
    public ResponseEntity<String> updateAllSectionPrices() {
        try {
            log.info("Manual price update triggered for all active sections");
            priceUpdateService.updateMonthlyPrices();
            return ResponseEntity.ok("Price update completed successfully for all active sections");
        } catch (Exception e) {
            log.error("Failed to update prices for all sections", e);
            return ResponseEntity.internalServerError()
                    .body("Failed to update prices: " + e.getMessage());
        }
    }
    
    /**
     * Manually trigger price update for a specific section
     */
    @PostMapping("/update/{sectionId}")
    public ResponseEntity<String> updateSectionPrice(@PathVariable String sectionId) {
        try {
            log.info("Manual price update triggered for section: {}", sectionId);
            priceUpdateService.updateSectionPrice(sectionId);
            return ResponseEntity.ok("Price updated successfully for section: " + sectionId);
        } catch (Exception e) {
            log.error("Failed to update price for section: {}", sectionId, e);
            return ResponseEntity.internalServerError()
                    .body("Failed to update price for section: " + e.getMessage());
        }
    }
}
