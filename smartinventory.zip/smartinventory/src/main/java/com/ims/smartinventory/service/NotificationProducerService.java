package com.ims.smartinventory.service;

public interface NotificationProducerService {
    void sendNotification(String userId, String message);
}
