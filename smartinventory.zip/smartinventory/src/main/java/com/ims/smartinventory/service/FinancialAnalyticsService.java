package com.ims.smartinventory.service;

public interface FinancialAnalyticsService {

}
