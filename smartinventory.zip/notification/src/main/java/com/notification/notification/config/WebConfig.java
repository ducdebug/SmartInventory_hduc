// This file has been removed as Spring Boot automatically handles static resource mapping
// Removing redundant configuration following DRY principle
