// This file has been removed as CORS is now configured in SecurityConfig
// to avoid redundancy and follow DRY principle
