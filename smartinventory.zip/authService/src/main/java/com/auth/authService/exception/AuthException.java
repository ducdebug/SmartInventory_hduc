package com.auth.authService.exception;

public class AuthException extends RuntimeException {
    public AuthException(String message) {
        super(message);
    }
}
