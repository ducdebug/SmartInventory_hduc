import type React from "react"
import { useEffect, useState } from "react"
import { useAuth } from "../../hooks/useAuth"
import { Alert, Input, Select, Card, Tag, Button, Modal, notification, InputNumber } from "antd"
import { SearchOutlined, ShoppingCartOutlined, EyeOutlined, PlusOutlined, MinusOutlined } from "@ant-design/icons"
import inventoryService from "../../services/inventoryService"
import "./BuyerDashboard.css"

const { Search } = Input
const { Option } = Select

interface ProductSummary {
  productId: string
  productType: string
  name: string
  detail: Record<string, any>
  count: number
  exportQuantity?: number
}

interface ProductDetailModalProps {
  product: ProductSummary | null
  isVisible: boolean
  onClose: () => void
  onQuantityChange: (quantity: number) => void
}

const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ product, isVisible, onClose, onQuantityChange }) => {
  if (!product) return null

  const handleQuantityChange = (value: number | null) => {
    const quantity = Math.max(0, Math.min(value || 0, product.count))
    onQuantityChange(quantity)
  }

  return (
    <Modal
      title={
        <div className="enhanced-modal-title">
          <EyeOutlined /> Product Details
        </div>
      }
      open={isVisible}
      onCancel={onClose}
      footer={[
        <Button key="close" onClick={onClose} className="enhanced-modal-button">
          Close
        </Button>,
      ]}
      width={800}
      className="enhanced-product-modal"
    >
      <div className="enhanced-product-detail-modal">
        <div className="enhanced-product-basic-info">
          <h3>{product.name}</h3>
          <div className="enhanced-product-meta">
            <Tag color="blue" className="enhanced-tag">
              {product.productType}
            </Tag>
            <Tag color="green" className="enhanced-tag">
              Available: {product.count}
            </Tag>
          </div>
        </div>

        <div className="enhanced-product-details-grid">
          {Object.entries(product.detail).map(([key, value]) => {
            if (key === "primaryPrice" || key === "primaryCurrency") {
              return null
            }

            let displayKey = key
              .replace(/_/g, " ")
              .replace(/([A-Z])/g, " $1")
              .trim()
            displayKey = displayKey.charAt(0).toUpperCase() + displayKey.slice(1)

            return (
              <div key={key} className="enhanced-detail-item">
                <span className="enhanced-detail-key">{displayKey}:</span>
                <span className="enhanced-detail-value">
                  {key === "secondaryPrice" && value ? (
                    <strong className="enhanced-price-value">
                      ${value} {product.detail.secondaryCurrency || "USD"}
                    </strong>
                  ) : (
                    String(value)
                  )}
                </span>
              </div>
            )
          })}
        </div>

        {!product.detail.secondaryPrice && (
          <Alert
            message="Price Not Available"
            description="The price for this product has not been set yet. Please contact the administrator."
            type="warning"
            className="enhanced-alert"
          />
        )}

        <div className="enhanced-modal-quantity-section">
          <h4>Request Quantity</h4>
          <div className="enhanced-quantity-controls">
            <Button
              icon={<MinusOutlined />}
              onClick={() => handleQuantityChange((product.exportQuantity || 0) - 1)}
              disabled={!product.exportQuantity || product.exportQuantity <= 0}
              className="enhanced-quantity-btn"
            />
            <InputNumber
              min={0}
              max={product.count}
              value={product.exportQuantity || 0}
              onChange={handleQuantityChange}
              className="enhanced-quantity-input"
            />
            <Button
              icon={<PlusOutlined />}
              onClick={() => handleQuantityChange((product.exportQuantity || 0) + 1)}
              disabled={(product.exportQuantity || 0) >= product.count}
              className="enhanced-quantity-btn"
            />
            <span className="enhanced-quantity-max">(max {product.count})</span>
          </div>
          {product.exportQuantity && product.exportQuantity > 0 && product.detail.secondaryPrice && (
            <div className="enhanced-quantity-total">
              <strong>
                Total: ${(product.exportQuantity * product.detail.secondaryPrice).toLocaleString()}{" "}
                {product.detail.secondaryCurrency || "USD"}
              </strong>
            </div>
          )}
        </div>
      </div>
    </Modal>
  )
}

const BuyerDashboard: React.FC = () => {
  const [products, setProducts] = useState<ProductSummary[]>([])
  const [filteredProducts, setFilteredProducts] = useState<ProductSummary[]>([])
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState<string>("")
  const [filterType, setFilterType] = useState<string>("all")
  const [selectedProduct, setSelectedProduct] = useState<ProductSummary | null>(null)
  const [isModalVisible, setIsModalVisible] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false)
  const [submitSuccess, setSubmitSuccess] = useState<boolean>(false)
  const [requestId, setRequestId] = useState<string | null>(null)

  const { user } = useAuth()

  useEffect(() => {
    if (user?.role !== "BUYER") {
      setError("Only buyers can access this dashboard")
      setIsLoading(false)
      return
    }

    fetchProducts()
  }, [user])

  useEffect(() => {
    applyFilters()
  }, [products, searchTerm, filterType])

  const fetchProducts = async () => {
    try {
      setIsLoading(true)
      setError(null)
      const data = await inventoryService.getAllProducts()
      setProducts(data)
    } catch (err: any) {
      console.error("Error fetching products:", err)
      setError("Failed to fetch products. Please try again later.")
    } finally {
      setIsLoading(false)
    }
  }

  const applyFilters = () => {
    let filtered = [...products]

    if (searchTerm) {
      filtered = filtered.filter(
        (product) =>
          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.productType.toLowerCase().includes(searchTerm.toLowerCase()) ||
          Object.values(product.detail).some((value) => String(value).toLowerCase().includes(searchTerm.toLowerCase())),
      )
    }

    if (filterType !== "all") {
      filtered = filtered.filter((product) => product.productType === filterType)
    }

    setFilteredProducts(filtered)
  }

  const handleProductClick = (product: ProductSummary) => {
    setSelectedProduct(product)
    setIsModalVisible(true)
  }

  const handleModalClose = () => {
    setIsModalVisible(false)
    setSelectedProduct(null)
  }

  const handleQuantityChange = (productId: string, quantity: number) => {
    const updatedProducts = products.map((product) =>
      product.productId === productId
        ? { ...product, exportQuantity: Math.max(0, Math.min(quantity, product.count)) }
        : product,
    )
    setProducts(updatedProducts)

    if (selectedProduct && selectedProduct.productId === productId) {
      setSelectedProduct({ ...selectedProduct, exportQuantity: Math.max(0, Math.min(quantity, selectedProduct.count)) })
    }
  }

  const handleModalQuantityChange = (quantity: number) => {
    if (selectedProduct) {
      handleQuantityChange(selectedProduct.productId, quantity)
    }
  }

  const handleSubmitRetrieveRequest = async () => {
    const productsToRetrieve = products
      .filter((p) => p.exportQuantity && p.exportQuantity > 0)
      .map((p) => ({
        productId: p.productId,
        name: p.name,
        detail: p.detail,
        quantity: p.exportQuantity!,
      }))

    if (productsToRetrieve.length === 0) {
      notification.warning({
        message: "Warning",
        description: "No products selected for retrieval.",
        placement: "topRight",
      })
      return
    }

    const totalPrice = productsToRetrieve.reduce((sum, product) => {
      const price = product.detail.secondaryPrice
      if (!price) {
        notification.error({
          message: "Error",
          description: "Request admin to set the price for all selected products.",
          placement: "topRight",
        })
        return sum
      }
      return sum + price * product.quantity
    }, 0)

    if (totalPrice === 0) return

    Modal.confirm({
      title: "Confirm Retrieval Request",
      className: "enhanced-confirm-modal",
      content: (
        <div className="enhanced-confirm-content">
          <p>
            <strong>
              Total Price: ${totalPrice.toLocaleString()} {productsToRetrieve[0].detail.secondaryCurrency}
            </strong>
          </p>
          <p>Products to retrieve:</p>
          <ul className="enhanced-product-list">
            {productsToRetrieve.map((product) => (
              <li key={product.productId} className="enhanced-product-item">
                <strong>{product.name}</strong> - Quantity: {product.quantity}
                {product.detail.secondaryPrice && (
                  <span className="enhanced-item-price">
                    {" "}
                    (${(product.detail.secondaryPrice * product.quantity).toLocaleString()})
                  </span>
                )}
              </li>
            ))}
          </ul>
        </div>
      ),
      onOk: async () => {
        try {
          setIsSubmitting(true)
          setError(null)
          const result = await inventoryService.createRetrieveRequest({ products: productsToRetrieve })
          setSubmitSuccess(true)
          if (result && typeof result === "string") {
            setRequestId(result)
          }
          const resetProducts = products.map((product) => ({
            ...product,
            exportQuantity: undefined,
          }))
          setProducts(resetProducts)

          notification.success({
            message: "Success",
            description: "Your retrieval request has been submitted successfully!",
            placement: "topRight",
          })
        } catch (err: any) {
          console.error("Retrieve request error:", err)
          if (err.response && err.response.status === 403) {
            setError("You do not have permission to create retrieve requests. Please check your account role.")
          } else if (err.message) {
            setError(`Failed to submit retrieval request: ${err.message}`)
          } else {
            setError("Failed to submit retrieval request. Please try again later.")
          }
          setSubmitSuccess(false)

          notification.error({
            message: "Error",
            description: "Failed to submit retrieval request. Please try again.",
            placement: "topRight",
          })
        } finally {
          setIsSubmitting(false)
        }
      },
    })
  }

  const handleResetSelection = () => {
    const resetProducts = products.map((product) => ({
      ...product,
      exportQuantity: undefined,
    }))
    setProducts(resetProducts)
    setSubmitSuccess(false)
    setRequestId(null)
  }

  const getUniqueProductTypes = () => {
    const types = products.map((p) => p.productType)
    return Array.from(new Set(types))
  }

  const getAvailabilityStatus = (count: number) => {
    if (count === 0) return { color: "red", text: "Out of Stock" }
    if (count < 10) return { color: "orange", text: "Low Stock" }
    return { color: "green", text: "In Stock" }
  }

  const getSelectedProductsCount = () => {
    return products.filter((p) => p.exportQuantity && p.exportQuantity > 0).length
  }

  const getSelectedProductsTotal = () => {
    return products
      .filter((p) => p.exportQuantity && p.exportQuantity > 0)
      .reduce((sum, product) => {
        const price = product.detail.secondaryPrice || 0
        return sum + price * (product.exportQuantity || 0)
      }, 0)
  }

  if (isLoading) {
    return (
      <div className="enhanced-buyer-dashboard">
        <div className="enhanced-dashboard-header">
          <div className="enhanced-header-content">
            <h1>
              <ShoppingCartOutlined /> Product Catalog
            </h1>
            <p>Browse and request products from our inventory</p>
          </div>
        </div>
        <div className="enhanced-loading-container">
          <div className="enhanced-loading-spinner" />
          <p>Loading products...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="enhanced-buyer-dashboard">
        <div className="enhanced-dashboard-header">
          <div className="enhanced-header-content">
            <h1>
              <ShoppingCartOutlined /> Product Catalog
            </h1>
            <p>Browse and request products from our inventory</p>
          </div>
        </div>
        <Alert
          message="Error"
          description={error}
          type="error"
          showIcon
          className="enhanced-error-alert"
          action={
            <Button size="small" onClick={fetchProducts} className="enhanced-retry-btn">
              Retry
            </Button>
          }
        />
      </div>
    )
  }

  if (submitSuccess) {
    return (
      <div className="enhanced-buyer-dashboard enhanced-success-state">
        <div className="enhanced-dashboard-header">
          <div className="enhanced-header-content">
            <h1>
              <ShoppingCartOutlined /> Product Catalog
            </h1>
            <p>Browse and request products from our inventory</p>
          </div>
        </div>
        <Alert
          message="Retrieval Request Submitted"
          description={
            <div className="enhanced-success-content">
              <p>Your product retrieval request has been submitted successfully!</p>
              <p className="enhanced-request-id">Request ID: {requestId || "Generated"}</p>
              <p>An administrator will review your request soon. You'll be notified when it's processed.</p>
            </div>
          }
          type="success"
          showIcon
          className="enhanced-success-alert"
        />
        <div className="enhanced-success-actions">
          <Button type="primary" onClick={handleResetSelection} className="enhanced-action-btn">
            Browse More Products
          </Button>
          <Button onClick={() => window.location.reload()} className="enhanced-action-btn">
            Refresh Page
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="enhanced-buyer-dashboard">
      <div className="enhanced-dashboard-header">
        <div className="enhanced-header-content">
          <h1>
            <ShoppingCartOutlined /> Product Catalog
          </h1>
          <p>Browse and request products from our inventory</p>
        </div>
      </div>

      <div className="enhanced-filters-section">
        <div className="enhanced-search-container">
          <Search
            placeholder="Search products by name, type, or details..."
            value={searchTerm}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchTerm(e.target.value)}
            prefix={<SearchOutlined />}
            allowClear
            size="large"
            className="enhanced-search-input"
          />
        </div>

        <div className="enhanced-filter-container">
          <Select value={filterType} onChange={setFilterType} size="large" className="enhanced-filter-select">
            <Option value="all">All Products</Option>
            {getUniqueProductTypes().map((type) => (
              <Option key={type} value={type}>
                {type}
              </Option>
            ))}
          </Select>
        </div>
      </div>

      <div className="enhanced-products-summary">
        <div className="enhanced-summary-stats">
          <div className="enhanced-stat-item">
            <div className="enhanced-stat-icon">📦</div>
            <span className="enhanced-stat-number">{filteredProducts.length}</span>
            <span className="enhanced-stat-label">Products Found</span>
          </div>
          <div className="enhanced-stat-item">
            <div className="enhanced-stat-icon">📊</div>
            <span className="enhanced-stat-number">{getUniqueProductTypes().length}</span>
            <span className="enhanced-stat-label">Product Types</span>
          </div>
          <div className="enhanced-stat-item">
            <div className="enhanced-stat-icon">📈</div>
            <span className="enhanced-stat-number">{filteredProducts.reduce((sum, p) => sum + p.count, 0)}</span>
            <span className="enhanced-stat-label">Total Items</span>
          </div>
          <div className="enhanced-stat-item enhanced-selected-stats">
            <div className="enhanced-stat-icon">🛒</div>
            <span className="enhanced-stat-number">{getSelectedProductsCount()}</span>
            <span className="enhanced-stat-label">Selected</span>
          </div>
        </div>
      </div>

      {getSelectedProductsCount() > 0 && (
        <div className="enhanced-cart-summary">
          <div className="enhanced-cart-info">
            <span className="enhanced-cart-count">{getSelectedProductsCount()} product(s) selected</span>
            <span className="enhanced-cart-total">Total: ${getSelectedProductsTotal().toLocaleString()} USD</span>
          </div>
          <div className="enhanced-cart-actions">
            <Button onClick={handleResetSelection} className="enhanced-cart-btn">
              Clear Selection
            </Button>
            <Button
              type="primary"
              loading={isSubmitting}
              onClick={handleSubmitRetrieveRequest}
              className="enhanced-cart-btn enhanced-submit-btn"
            >
              {isSubmitting ? "Submitting..." : "Submit Request"}
            </Button>
          </div>
        </div>
      )}

      {filteredProducts.length === 0 ? (
        <div className="enhanced-no-products">
          <ShoppingCartOutlined className="enhanced-no-products-icon" />
          <h3>No products found</h3>
          <p>Try adjusting your search criteria or filters</p>
        </div>
      ) : (
        <div className="enhanced-products-grid">
          {filteredProducts.map((product) => {
            const availability = getAvailabilityStatus(product.count)
            const hasQuantitySelected = product.exportQuantity && product.exportQuantity > 0

            return (
              <Card
                key={product.productId}
                className={`enhanced-product-card ${hasQuantitySelected ? "enhanced-selected" : ""}`}
                hoverable
                actions={[
                  <Button
                    key="view"
                    type="link"
                    icon={<EyeOutlined />}
                    onClick={(e: React.MouseEvent<HTMLElement>) => {
                      e.stopPropagation()
                      handleProductClick(product)
                    }}
                    className="enhanced-view-btn"
                  >
                    View Details
                  </Button>,
                ]}
              >
                <div className="enhanced-product-card-content">
                  <div className="enhanced-product-header">
                    <h3 className="enhanced-product-name">{product.name}</h3>
                    <Tag color="blue" className="enhanced-product-type-tag">
                      {product.productType}
                    </Tag>
                  </div>

                  <div className="enhanced-product-info">
                    <div className="enhanced-availability-info">
                      <Tag color={availability.color} className="enhanced-availability-tag">
                        {availability.text} ({product.count} units)
                      </Tag>
                    </div>

                    {product.detail.secondaryPrice ? (
                      <div className="enhanced-price-info">
                        <span className="enhanced-price">
                          ${product.detail.secondaryPrice} {product.detail.secondaryCurrency || "USD"}
                        </span>
                      </div>
                    ) : (
                      <div className="enhanced-price-info">
                        <span className="enhanced-price-na">Price not set</span>
                      </div>
                    )}
                  </div>

                  <div className="enhanced-product-preview">
                    {Object.entries(product.detail)
                      .filter(
                        ([key]) =>
                          !["primaryPrice", "primaryCurrency", "secondaryPrice", "secondaryCurrency"].includes(key),
                      )
                      .slice(0, 2)
                      .map(([key, value]) => (
                        <div key={key} className="enhanced-preview-item">
                          <span className="enhanced-preview-key">
                            {key
                              .replace(/_/g, " ")
                              .replace(/([A-Z])/g, " $1")
                              .trim()}
                            :
                          </span>
                          <span className="enhanced-preview-value">{String(value)}</span>
                        </div>
                      ))}
                  </div>

                  <div className="enhanced-quantity-section">
                    <div className="enhanced-quantity-controls">
                      <Button
                        size="small"
                        icon={<MinusOutlined />}
                        onClick={(e: React.MouseEvent<HTMLElement>) => {
                          e.stopPropagation()
                          handleQuantityChange(product.productId, (product.exportQuantity || 0) - 1)
                        }}
                        disabled={!product.exportQuantity || product.exportQuantity <= 0}
                        className="enhanced-quantity-btn"
                      />
                      <InputNumber
                        size="small"
                        min={0}
                        max={product.count}
                        value={product.exportQuantity || 0}
                        onChange={(value: number | null) => handleQuantityChange(product.productId, value || 0)}
                        className="enhanced-quantity-input"
                        onClick={(e: React.MouseEvent<HTMLInputElement>) => e.stopPropagation()}
                      />
                      <Button
                        size="small"
                        icon={<PlusOutlined />}
                        onClick={(e: React.MouseEvent<HTMLElement>) => {
                          e.stopPropagation()
                          handleQuantityChange(product.productId, (product.exportQuantity || 0) + 1)
                        }}
                        disabled={(product.exportQuantity || 0) >= product.count}
                        className="enhanced-quantity-btn"
                      />
                    </div>
                    {hasQuantitySelected && product.detail.secondaryPrice && (
                      <div className="enhanced-quantity-total">
                        <strong>
                          ${(product.exportQuantity! * product.detail.secondaryPrice).toLocaleString()}{" "}
                          {product.detail.secondaryCurrency || "USD"}
                        </strong>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            )
          })}
        </div>
      )}

      <ProductDetailModal
        product={selectedProduct}
        isVisible={isModalVisible}
        onClose={handleModalClose}
        onQuantityChange={handleModalQuantityChange}
      />
    </div>
  )
}

export default BuyerDashboard
